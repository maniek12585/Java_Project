package pl.polsl.PawelZachara.project.Model;

/**
* @author  Paweł Zachara
* @version 1.1
 *@since   2019-11-02
*/

/**
* enum tpye used to define snake moving direction
*/
public enum Direction {
    UP,
    DOWN,
    LEFT,
    RIGHT
}
